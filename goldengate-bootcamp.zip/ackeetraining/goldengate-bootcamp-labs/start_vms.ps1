# pwsh
# This script is distributed on an "as is" basis
# without warranties or conditions of any kind.
# Feel free to modify or use it.

# $Env:VAGRANT_EXPERIMENTAL="disks"
$vms = "cntlr","ogg1","ogg2"
foreach ($vm in $vms) {
  & 'C:\Program Files\Oracle\VirtualBox\VBoxManage.exe' startvm $vm --type headless
}
