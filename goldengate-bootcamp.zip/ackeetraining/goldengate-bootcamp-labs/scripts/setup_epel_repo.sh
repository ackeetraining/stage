# Install EPEL repo
dnf install oracle-epel-release-el8 -y