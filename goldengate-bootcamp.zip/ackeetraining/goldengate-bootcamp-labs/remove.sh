#!/bin/bash
# This script is distributed on an "as is" basis
# without warranties or conditions of any kind.
# Feel free to modify or use it.

export VAGRANT_EXPERIMENTAL="disks"
vagrant destroy --color --force
